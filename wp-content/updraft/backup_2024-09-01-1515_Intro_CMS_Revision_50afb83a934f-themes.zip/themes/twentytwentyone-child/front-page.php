<?php
get_header();


/**
 * champs_accueil --> extract the fields
 */

 
/**
 * verify if the fields are retrieving
 */
/* var_dump( $champs_accueil ); */

/**
 * specific fields
 */
/* echo $champs_accueil['accueil_introduction']; */
/* echo $champs_accueil['accueil_contenu']; */


$champs_accueil = get_fields();
$accueil_introduction =  $champs_accueil['accueil_introduction'];
$accueil_url_hero =  $champs_accueil['accueil_url_hero'];
$accueil_contenu =  $champs_accueil['accueil_contenu'];
?>
<div class="wrapper">
    <?php if( $accueil_introduction ) : ?>
        <h2><?php echo esc_html($accueil_introduction); ?></h2>
    <?php endif; ?>

    <?php if( $accueil_url_hero ) : ?>
        <div class="mt-large">
            <img src="<?php echo esc_html($accueil_url_hero); ?>" alt="Random PHP" />
        </div>
    <?php endif; ?>

    <?php if( $accueil_contenu ) : ?>
        <div class="wysiwyg"><?php echo $accueil_contenu; ?></div>
    <?php endif; ?>
</div>
<?php


get_footer();


?>
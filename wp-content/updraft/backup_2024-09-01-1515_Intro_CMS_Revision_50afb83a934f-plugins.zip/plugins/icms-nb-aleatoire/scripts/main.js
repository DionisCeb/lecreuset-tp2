window.addEventListener('DOMContentLoaded', function() {

    const elRandom = document.querySelector('[data-js-random');

    elRandom.addEventListener('click', function() {
        let nbAleatoire = Math.floor(Math.random() * 100);
        elRandom.textContent = nbAleatoire;
    });

});

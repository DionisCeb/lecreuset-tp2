<?php
/*
Plugin Name: Nombre aleatoire
Description: Injecte un nombre aleatoire
Author: Dionis Cebanu
Version: 1
*/


function na_tire_nb_aleatoire( $wysiwyg ) {
    $nbAleatoire = rand( 0, 100 );
    return str_replace( '[rand]', $nbAleatoire, $wysiwyg);
}

add_filter( 'acf/load_value/name=accueil_contenu', 'na_tire_nb_aleatoire');


function na_ajouter_styles_et_scripts() {
    /* wp_register_style( 'id-style', plugins_url( 'styles/styles.css', __FILE__ ) );
    wp_enqueue_style( 'id-style' ); */

    wp_register_script( 'id-nb-aleatoire', plugins_url( 'scripts/main.js', __FILE__ ) );
    wp_enqueue_script( 'id-nb-aleatoire' );
    }
    // add_action( 'init', 'mpp_ajouter_styles_et_scripts' );
    add_action( 'wp_enqueue_scripts', 'na_ajouter_styles_et_scripts' );

?>